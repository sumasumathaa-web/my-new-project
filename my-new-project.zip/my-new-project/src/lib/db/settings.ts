import "server-only";
import { safeServiceSupabase } from "@/lib/supabase/admin";

/** Settings store: single settings rows keyed by name. All public strings live here — no brand is hardcoded. */

export const BSetKeys = [
  "business_name",
  "tagline",
  "logo_url",
  "favicon_url",
  "primary_color",
  "accent_color",
  "support_email",
  "support_phone",
  "whatsapp",
  "instagram",
  "facebook",
  "youtube",
  "twitter",
] as const;

export type BSetKeys = (typeof BSetKeys)[number];

/** Loose record of the branding bucket; missing keys fall back to defaults. */
export async function brSet(): Promise<Record<string, string>> {
  const sb = safeServiceSupabase();
  if (!sb) return {};
  const { data } = await sb.from("settings").select("value").eq("key", "branding").maybeSingle();
  return (data?.value as Record<string, string> | null) ?? {};
}

/** Single branding string with fallback. */
export async function brandingGet(key: string, fallback = "Your Brand Name"): Promise<string> {
  const all = await brSet();
  return all[key] ?? fallback;
}

export interface HomepageSet {
  hero_title: string;
  hero_subtitle: string;
  hero_image_url: string;
  cta_label: string;
  cta_url: string;
  announcement_enabled: boolean;
  announcement_text: string;
  announcement_url: string;
  footer_text: string;
  sections: string[];
}

const H_DEF: HomepageSet = {
  hero_title: "Invitations that feel like the wedding itself",
  hero_subtitle: "Cinematic video invites, elegant websites, keepsake cards.",
  hero_image_url: "",
  cta_label: "Browse invitations",
  cta_url: "/invitation-videos",
  announcement_enabled: false,
  announcement_text: "",
  announcement_url: "",
  footer_text: "Crafted with care by our studio. Demo content is fictional.",
  sections: ["hero", "featured", "themes", "quotes", "how"],
};

export async function hSet(): Promise<HomepageSet> {
  const sb = safeServiceSupabase();
  if (!sb) return H_DEF;
  const { data } = await sb.from("settings").select("value").eq("key", "homepage").maybeSingle();
  return { ...H_DEF, ...((data?.value as Partial<HomepageSet> | null) ?? {}) };
}

/** Merges a partial branding patch and persists. */
export async function brandingUpdateMany(patch: Record<string, string>): Promise<void> {
  const sb = safeServiceSupabase();
  if (!sb) throw new Error("Database is not configured.");
  const { data: existing } = await sb.from("settings").select("value").eq("key", "branding").maybeSingle();
  const merged = { ...((existing?.value as Record<string, string> | null) ?? {}) };
  for (const [k, v] of Object.entries(patch)) merged[k] = v.trim();
  const { error } = await sb.from("settings").upsert({ key: "branding", value: merged, updated_at: new Date().toISOString() });
  if (error) throw new Error(error.message);
}

export async function notificationsUpdate(
  userId: string,
  patch: { marketing_opt_in?: boolean }
): Promise<void> {
  const sb = safeServiceSupabase();
  if (!sb) throw new Error("Database is not configured.");
  const { error } = await sb
    .from("profiles")
    .update({ marketing_opt_in: patch.marketing_opt_in ?? false, updated_at: new Date().toISOString() })
    .eq("id", userId);
  if (error) throw new Error(error.message);
}
