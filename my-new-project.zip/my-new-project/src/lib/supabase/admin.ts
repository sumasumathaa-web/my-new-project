import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { env, hasServiceRole } from "@/lib/env";

/**
 * Service-role client: bypasses RLS. SERVER ONLY.
 * Never import this from a client component.
 */
let cached: SupabaseClient | null = null;

export function getServiceSupabase(): SupabaseClient {
  if (!hasServiceRole()) {
    throw new Error(
      "Supabase service role is not configured. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.",
    );
  }
  if (!cached) {
    cached = createClient(env.supabaseUrl, env.supabaseServiceKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }
  return cached;
}

/** Like getServiceSupabase but returns null instead of throwing (for build-time safety). */
export function safeServiceSupabase(): SupabaseClient | null {
  try {
    return hasServiceRole() ? getServiceSupabase() : null;
  } catch {
    return null;
  }
}
