import { cookies } from "next/headers";
import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { env, hasSupabase } from "@/lib/env";

/**
 * Cookie-bound Supabase client for Server Components & Route Handlers.
 * Carries the end-user session (RLS applies as that user).
 */
export function getServerSupabase() {
  const cookieStore = cookies();
  return createServerClient(env.supabaseUrl, env.supabaseAnonKey, {
    cookies: {
      get(name: string) {
        return cookieStore.get(name)?.value;
      },
      set(name: string, value: string, options: CookieOptions) {
        try {
          cookieStore.set({ name, value, ...options });
        } catch {
          /* called from a Server Component — middleware refreshes tokens */
        }
      },
      remove(name: string, options: CookieOptions) {
        try {
          cookieStore.set({ name, value: "", ...options });
        } catch {
          /* noop */
        }
      },
    },
  });
}

export function safeServerSupabase() {
  return hasSupabase() ? getServerSupabase() : null;
}
